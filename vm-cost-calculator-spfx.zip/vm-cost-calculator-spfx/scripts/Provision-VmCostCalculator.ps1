<#
.SYNOPSIS
  Creates the 4 lists, seeds the pricing from VM_Cost_Calculation.xlsx and creates the ASPX page
  with the "VM Cost Calculator" web part.

.NOTES
  Requires PnP.PowerShell. Run AFTER the .sppkg has been uploaded to the App Catalog and the app
  has been added to the target site. Run as a site owner.

.EXAMPLE
  .\Provision-VmCostCalculator.ps1 -SiteUrl https://contoso.sharepoint.com/sites/IT -ClientId <your-entra-app-id>
#>
param(
  [Parameter(Mandatory = $true)][string]$SiteUrl,
  [string]$ClientId,                                   # needed by PnP.PowerShell 2.x for interactive login
  [string]$PageName = "VM-Cost-Calculator",
  [string]$WebPartTitle = "VM Cost Calculator"
)
$ErrorActionPreference = "Stop"

if ($ClientId) { Connect-PnPOnline -Url $SiteUrl -Interactive -ClientId $ClientId }
else           { Connect-PnPOnline -Url $SiteUrl -Interactive }

function Ensure-List([string]$Title, [string]$UrlName) {
  if (-not (Get-PnPList -Identity $Title -ErrorAction SilentlyContinue)) {
    Write-Host "Creating list '$Title'"
    New-PnPList -Title $Title -Url "Lists/$UrlName" -Template GenericList -OnQuickLaunch | Out-Null
  }
}
function Ensure-Field([string]$List, [string]$Internal, [string]$Display, [string]$Type, [string[]]$Choices) {
  if (Get-PnPField -List $List -Identity $Internal -ErrorAction SilentlyContinue) { return }
  $p = @{ List = $List; DisplayName = $Display; InternalName = $Internal; Type = $Type; AddToDefaultView = $true }
  if ($Choices) { $p.Choices = $Choices }
  Add-PnPField @p | Out-Null
  if ($Type -eq "Note") { Set-PnPField -List $List -Identity $Internal -Values @{ RichText = $false } | Out-Null }
}
function Ensure-Bool([string]$List, [string]$Internal, [string]$Display) {
  if (Get-PnPField -List $List -Identity $Internal -ErrorAction SilentlyContinue) { return }
  Add-PnPField -List $List -DisplayName $Display -InternalName $Internal -Type Boolean -AddToDefaultView -DefaultValue "1" | Out-Null
}
function Is-Empty([string]$List) { return ((Get-PnPListItem -List $List -PageSize 1 | Measure-Object).Count -eq 0) }

# ---------------------------------------------------------------- 1) Rates (configuration)
$rates = "VM Cost Rates"
Ensure-List $rates "VMCostRates"
Set-PnPField -List $rates -Identity "Title" -Values @{ Required = $false } | Out-Null
Ensure-Field $rates "Environment"       "Environment"                    "Text"
Ensure-Field $rates "Workload"          "Workload"                       "Text"
Ensure-Field $rates "OperatingSystem"   "Operating System"               "Text"
Ensure-Field $rates "VcpuCost"          "vCPU Core Cost"                 "Number"
Ensure-Field $rates "MemoryCost"        "Memory (1GB) Cost"              "Number"
Ensure-Field $rates "StorageCost"       "Storage (1GB) Cost"             "Number"
Ensure-Field $rates "WindowsOSCost"     "Windows OS (per vCPU) Cost"     "Number"
Ensure-Field $rates "RedhatLicenseCost" "Redhat License (per VM) Cost"   "Number"
Ensure-Bool  $rates "IsActive"          "Active"

if (Is-Empty $rates) {
  Write-Host "Seeding rates from the Excel file"
  $base = @(
    @{ Env = "Non-Prod";   Wl = "Application"; V = 132.13; M = 307.80; S = 14.29 },
    @{ Env = "Non-Prod";   Wl = "Database";    V = 198.20; M = 307.80; S = 14.29 },
    @{ Env = "Production"; Wl = "Application"; V = 190.20; M = 267.81; S = 21.40 },
    @{ Env = "Production"; Wl = "Database";    V = 380.41; M = 267.81; S = 27.35 }
  )
  foreach ($b in $base) {
    foreach ($os in @("Windows", "Redhat", 'Custom OS\Upgrade')) {
      $win = 0; $rh = 0
      if ($os -eq "Windows") { $win = 24.22 }
      if ($os -eq "Redhat")  { $rh = 2677.99 }
      Add-PnPListItem -List $rates -Values @{
        Title = "$($b.Env) | $($b.Wl) | $os"; Environment = $b.Env; Workload = $b.Wl; OperatingSystem = $os
        VcpuCost = $b.V; MemoryCost = $b.M; StorageCost = $b.S; WindowsOSCost = $win; RedhatLicenseCost = $rh; IsActive = $true
      } | Out-Null
    }
  }
}

# ---------------------------------------------------------------- 2) Settings (cost increase %)
$settings = "VM Cost Settings"
Ensure-List $settings "VMCostSettings"
Ensure-Field $settings "SettingValue" "Value" "Number"
if (Is-Empty $settings) {
  Add-PnPListItem -List $settings -Values @{ Title = "CostIncreaseAdjPercent"; SettingValue = 10 } | Out-Null   # 10 = 10 %
}

# ---------------------------------------------------------------- 3) Optional add-ons (configuration)
$addons = "VM Cost Addons"
Ensure-List $addons "VMCostAddons"
Ensure-Field $addons "UnitPrice" "Unit Price" "Number"
Ensure-Field $addons "Basis" "Basis" "Choice" @("Per VM", "Per vCPU", "Per GB Memory", "Per GB Storage")
Ensure-Bool  $addons "IsActive" "Active"

# ---------------------------------------------------------------- 4) Saved estimates
$req = "VM Cost Requests"
Ensure-List $req "VMCostRequests"
Ensure-Field $req "Environment"     "Environment"        "Text"
Ensure-Field $req "Workload"        "Workload"           "Text"
Ensure-Field $req "OperatingSystem" "Operating System"   "Text"
Ensure-Field $req "VcpuCores"       "vCPU (Cores)"       "Number"
Ensure-Field $req "MemoryGB"        "Memory (GB)"        "Number"
Ensure-Field $req "StorageGB"       "Storage (GB)"       "Number"
Ensure-Field $req "VmCount"         "Number of VMs"      "Number"
Ensure-Field $req "VmCost"          "VM Cost (per VM)"   "Number"
Ensure-Field $req "AddonsCost"      "Add-ons Cost (per VM)" "Number"
Ensure-Field $req "AdjPercent"      "Cost Increase Adj %" "Number"
Ensure-Field $req "TotalCost"       "Total Cost"         "Number"
Ensure-Field $req "SelectedAddons"  "Selected Add-ons"   "Note"
Ensure-Field $req "Notes"           "Notes"              "Note"
Ensure-Field $req "RatesSnapshot"   "Rates Snapshot"     "Note"
Set-PnPField -List $req -Identity "Title" -Values @{ Title = "Request / VM Name" } | Out-Null

# ---------------------------------------------------------------- 5) ASPX page
$page = $null
try { $page = Get-PnPPage -Identity $PageName -ErrorAction Stop } catch { }
if (-not $page) {
  Write-Host "Creating page $PageName.aspx"
  Add-PnPPage -Name $PageName -Title "VM Cost Calculator" -LayoutType Article -HeaderLayoutType NoImage | Out-Null
  Add-PnPPageSection -Page $PageName -SectionTemplate OneColumn -Order 1
  Add-PnPPageWebPart -Page $PageName -Component $WebPartTitle
  Set-PnPPage -Identity $PageName -Publish
}
Write-Host "Done. Open: $SiteUrl/SitePages/$PageName.aspx"
