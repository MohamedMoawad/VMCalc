# VM Cost Calculator (SPFx + React, SharePoint Online)

A web part that reproduces the logic of `VM Cost Calculation - Consolidated.xlsx`:

    VM Cost = vCPU x vCPU rate + Memory GB x Memory rate + Storage GB x Storage rate
              + vCPU x Windows rate + (Redhat license per VM)
    Total   = VM Cost x (1 + Cost Increase Adj %)

The user fills the form, sees the amount update live, and clicks **Save estimate** to store it in a list.

## Lists (created by the script)
| List | Purpose | Who edits |
|---|---|---|
| VM Cost Rates | One row per Environment / Workload / OS with all unit prices (seeded from the Excel Sheet2). Add a row to add a new environment, workload or OS - the dropdowns update automatically. Untick Active to hide a row. | Admins |
| VM Cost Settings | `CostIncreaseAdjPercent` (10 = 10%) | Admins |
| VM Cost Addons | Optional extra items (name, unit price, basis: per VM / vCPU / GB memory / GB storage). Active add-ons appear as checkboxes on the form. | Admins |
| VM Cost Requests | Saved estimates (inputs, per-VM cost, add-ons, adj %, total, rate snapshot) | Everyone (Contribute) |

Tip: give normal users Read on the first three lists and Contribute on VM Cost Requests only.

## Build and deploy
Prereqs: Node 18 LTS, `npm i -g yo gulp-cli @microsoft/generator-sharepoint`, PnP.PowerShell.

1. Scaffold the project shell (gives you the correct config files for your SPFx version):

       yo @microsoft/sharepoint
       - Solution name:  vm-cost-calculator
       - Target:         SharePoint Online only (latest)
       - Folder:         Use the current folder (empty folder)
       - Tenant-wide deployment: No
       - Component:      WebPart
       - Web part name:  VmCostCalculator
       - Framework:      React

2. Copy this zip's `src` folder over the generated `src` (overwrite when asked), and put `scripts/` next to it.
   The manifest keeps a fixed web part id, so do not regenerate it.
3. Build and package:

       npm install
       gulp bundle --ship
       gulp package-solution --ship

4. Upload `sharepoint/solution/vm-cost-calculator.sppkg` to the App Catalog, then add the app to the target site (Site contents > New > App).
5. Provision lists, seed data and the page:

       .\scripts\Provision-VmCostCalculator.ps1 -SiteUrl https://<tenant>.sharepoint.com/sites/<site> -ClientId <entra-app-id>

   Page: `<site>/SitePages/VM-Cost-Calculator.aspx`

For local testing use `gulp serve` and open `<site>/_layouts/15/workbench.aspx`.

## Notes
- Number of VMs (default 1) and add-ons are additions to the Excel logic; leave VMs at 1 and add-ons unticked to match the sheet exactly.
- Verified: the calculation code reproduces all 12 Total Cost values in the Excel file.
- Each saved request keeps a JSON snapshot of the rates used, so later price changes never alter old estimates.
