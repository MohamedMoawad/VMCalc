import { SPHttpClient, SPHttpClientResponse } from '@microsoft/sp-http';
import { AddonBasis, IAddon, IRate, ISavedRequest } from './types';
import { num } from './calc';

/** List display titles + URL names (must match scripts/Provision-VmCostCalculator.ps1). */
export const LISTS = {
  rates:    { title: 'VM Cost Rates',    url: 'Lists/VMCostRates' },
  addons:   { title: 'VM Cost Addons',   url: 'Lists/VMCostAddons' },
  settings: { title: 'VM Cost Settings', url: 'Lists/VMCostSettings' },
  requests: { title: 'VM Cost Requests', url: 'Lists/VMCostRequests' }
};
export type ListKey = keyof typeof LISTS;

export const ADJ_SETTING_KEY = 'CostIncreaseAdjPercent';

export interface INewRequest {
  Title: string;
  Environment: string;
  Workload: string;
  OperatingSystem: string;
  VcpuCores: number;
  MemoryGB: number;
  StorageGB: number;
  VmCount: number;
  VmCost: number;
  AddonsCost: number;
  AdjPercent: number;
  TotalCost: number;
  SelectedAddons: string;
  RatesSnapshot: string;
  Notes: string;
}

export class VmCostService {
  constructor(private http: SPHttpClient, private webUrl: string) {}

  public listUrl(key: ListKey): string {
    return `${this.webUrl}/${LISTS[key].url}`;
  }

  private listApi(key: ListKey): string {
    return `${this.webUrl}/_api/web/lists/getbytitle('${LISTS[key].title}')`;
  }

  private async getJson<T>(url: string): Promise<T> {
    const res: SPHttpClientResponse = await this.http.get(url, SPHttpClient.configurations.v1, {
      headers: { Accept: 'application/json;odata=nometadata', 'odata-version': '' }
    });
    if (!res.ok) throw new Error(await this.errorText(res, url));
    return res.json() as Promise<T>;
  }

  private async errorText(res: SPHttpClientResponse, url: string): Promise<string> {
    if (res.status === 404 && url.indexOf('/lists/getbytitle') > -1) {
      return 'A required list was not found. Run scripts/Provision-VmCostCalculator.ps1 on this site first.';
    }
    try {
      const j = await res.json();
      return (j && j.error && (j.error.message.value || j.error.message)) || `${res.status} ${res.statusText}`;
    } catch {
      return `${res.status} ${res.statusText}`;
    }
  }

  public async getRates(): Promise<IRate[]> {
    const sel = 'Id,Environment,Workload,OperatingSystem,VcpuCost,MemoryCost,StorageCost,WindowsOSCost,RedhatLicenseCost,IsActive';
    const j = await this.getJson<{ value: any[] }>(`${this.listApi('rates')}/items?$select=${sel}&$top=5000`);
    return j.value
      .filter(r => r.IsActive !== false && r.Environment && r.Workload && r.OperatingSystem)
      .map((r): IRate => ({
        Id: r.Id,
        Environment: String(r.Environment).trim(),
        Workload: String(r.Workload).trim(),
        OperatingSystem: String(r.OperatingSystem).trim(),
        VcpuCost: num(r.VcpuCost),
        MemoryCost: num(r.MemoryCost),
        StorageCost: num(r.StorageCost),
        WindowsOSCost: num(r.WindowsOSCost),
        RedhatLicenseCost: num(r.RedhatLicenseCost)
      }));
  }

  public async getAddons(): Promise<IAddon[]> {
    try {
      const j = await this.getJson<{ value: any[] }>(
        `${this.listApi('addons')}/items?$select=Id,Title,UnitPrice,Basis,IsActive&$top=500`);
      return j.value
        .filter(a => a.IsActive !== false && a.Title)
        .map((a): IAddon => ({ Id: a.Id, Title: a.Title, UnitPrice: num(a.UnitPrice), Basis: (a.Basis || 'Per VM') as AddonBasis }));
    } catch {
      return []; // add-ons are optional
    }
  }

  /** Cost-increase adjustment, in percent (10 = 10 %). */
  public async getAdjPercent(): Promise<number> {
    const j = await this.getJson<{ value: any[] }>(`${this.listApi('settings')}/items?$select=Title,SettingValue&$top=100`);
    const row = j.value.filter(s => s.Title === ADJ_SETTING_KEY)[0];
    return row ? num(row.SettingValue) : 0;
  }

  public async getMyRequests(): Promise<ISavedRequest[]> {
    try {
      const me = await this.getJson<{ Id: number }>(`${this.webUrl}/_api/web/currentuser?$select=Id`);
      const j = await this.getJson<{ value: any[] }>(
        `${this.listApi('requests')}/items?$select=Id,Title,Environment,Workload,OperatingSystem,TotalCost,Created` +
        `&$filter=AuthorId eq ${me.Id}&$orderby=Created desc&$top=10`);
      return j.value.map((r): ISavedRequest => ({ ...r, TotalCost: num(r.TotalCost) }));
    } catch {
      return [];
    }
  }

  public async createRequest(item: INewRequest): Promise<void> {
    const url = `${this.listApi('requests')}/items`;
    const res = await this.http.post(url, SPHttpClient.configurations.v1, {
      headers: {
        Accept: 'application/json;odata=nometadata',
        'Content-type': 'application/json;odata=nometadata',
        'odata-version': ''
      },
      body: JSON.stringify(item)
    });
    if (!res.ok) throw new Error(await this.errorText(res, url));
  }
}
