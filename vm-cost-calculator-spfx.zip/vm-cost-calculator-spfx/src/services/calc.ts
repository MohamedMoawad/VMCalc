import { IAddon, IAddonLine, ICostBreakdown, IInputs, IRate } from './types';

/** Safe number coercion (SharePoint returns null for blank number fields). */
export const num = (v: unknown): number => {
  const n = typeof v === 'number' ? v : parseFloat(String(v === undefined || v === null ? '' : v));
  return isFinite(n) ? n : 0;
};

export const round2 = (n: number): number => Math.round((n + 1e-9) * 100) / 100;

/**
 * Same maths as the Excel sheet:
 *   VM Cost  = cores*vCPU + memory*memRate + storage*storRate + cores*windowsPerVcpu + (cores>0 ? redhatPerVm : 0)
 *   Total    = VM Cost * (1 + adj%)
 * Extras: optional add-ons (per VM / vCPU / GB) and a VM count multiplier.
 */
export function calculate(rate: IRate, input: IInputs, addons: IAddon[], adjPercent: number): ICostBreakdown {
  const vcpu = input.cores * rate.VcpuCost;
  const memory = input.memoryGB * rate.MemoryCost;
  const storage = input.storageGB * rate.StorageCost;
  const windows = input.cores * rate.WindowsOSCost;
  const redhat = input.cores > 0 ? rate.RedhatLicenseCost : 0;
  const vmCost = vcpu + memory + storage + windows + redhat;

  const addonLines: IAddonLine[] = addons.map((a): IAddonLine => {
    let quantity = 1;
    if (a.Basis === 'Per vCPU') quantity = input.cores;
    else if (a.Basis === 'Per GB Memory') quantity = input.memoryGB;
    else if (a.Basis === 'Per GB Storage') quantity = input.storageGB;
    return { id: a.Id, name: a.Title, basis: a.Basis, unitPrice: a.UnitPrice, quantity, amount: quantity * a.UnitPrice };
  });
  const addonsCost = addonLines.reduce((s, l) => s + l.amount, 0);

  const subtotal = (vmCost + addonsCost) * Math.max(1, input.vmCount);
  const adjAmount = subtotal * adjPercent / 100;
  return {
    vcpu, memory, storage, windows, redhat, vmCost,
    addonLines, addonsCost, subtotal, adjPercent, adjAmount,
    total: subtotal + adjAmount
  };
}
