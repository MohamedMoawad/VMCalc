export type AddonBasis = 'Per VM' | 'Per vCPU' | 'Per GB Memory' | 'Per GB Storage';

/** One row of the "VM Cost Rates" configuration list. */
export interface IRate {
  Id: number;
  Environment: string;
  Workload: string;
  OperatingSystem: string;
  VcpuCost: number;            // price per vCPU core
  MemoryCost: number;          // price per 1 GB memory
  StorageCost: number;         // price per 1 GB storage
  WindowsOSCost: number;       // Windows OS price per vCPU
  RedhatLicenseCost: number;   // Red Hat license price per VM
}

/** One row of the "VM Cost Addons" configuration list. */
export interface IAddon {
  Id: number;
  Title: string;
  UnitPrice: number;
  Basis: AddonBasis;
}

export interface IInputs {
  cores: number;
  memoryGB: number;
  storageGB: number;
  vmCount: number;
}

export interface IAddonLine {
  id: number;
  name: string;
  basis: AddonBasis;
  unitPrice: number;
  quantity: number;
  amount: number;
}

export interface ICostBreakdown {
  vcpu: number;
  memory: number;
  storage: number;
  windows: number;
  redhat: number;
  vmCost: number;          // = Excel "VM Cost ($)" for one VM
  addonLines: IAddonLine[];
  addonsCost: number;      // per VM
  subtotal: number;        // (vmCost + addonsCost) x vmCount
  adjPercent: number;
  adjAmount: number;
  total: number;           // = Excel "Total Cost ($)"
}

export interface ISavedRequest {
  Id: number;
  Title: string;
  Environment: string;
  Workload: string;
  OperatingSystem: string;
  TotalCost: number;
  Created: string;
}
