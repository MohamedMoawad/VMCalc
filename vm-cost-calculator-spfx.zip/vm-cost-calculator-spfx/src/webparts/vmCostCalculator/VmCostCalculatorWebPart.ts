import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';

import VmCostCalculator from './components/VmCostCalculator';
import { IVmCostCalculatorProps } from './components/IVmCostCalculatorProps';
import { VmCostService } from '../../services/VmCostService';

export default class VmCostCalculatorWebPart extends BaseClientSideWebPart<object> {
  private _service!: VmCostService;

  protected onInit(): Promise<void> {
    this._service = new VmCostService(this.context.spHttpClient, this.context.pageContext.web.absoluteUrl);
    return super.onInit();
  }

  public render(): void {
    const element: React.ReactElement<IVmCostCalculatorProps> = React.createElement(VmCostCalculator, {
      service: this._service
    });
    ReactDom.render(element, this.domElement);
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }
}
