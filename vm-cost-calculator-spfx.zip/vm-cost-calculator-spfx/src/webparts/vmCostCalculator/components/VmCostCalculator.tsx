import * as React from 'react';
import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Checkbox, DefaultButton, Dropdown, IDropdownOption, MessageBar, MessageBarType,
  PrimaryButton, Spinner, SpinnerSize, TextField
} from '@fluentui/react';
import styles from './VmCostCalculator.module.scss';
import { IVmCostCalculatorProps } from './IVmCostCalculatorProps';
import { calculate, num, round2 } from '../../../services/calc';
import { IAddon, IRate, ISavedRequest } from '../../../services/types';

const fmt = new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' });
const money = (n: number): string => fmt.format(n);
const distinct = (v: string[]): string[] => v.filter((x, i) => x && v.indexOf(x) === i);
const toOptions = (v: string[]): IDropdownOption[] => v.map(x => ({ key: x, text: x }));

const VmCostCalculator: React.FC<IVmCostCalculatorProps> = ({ service }) => {
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string>();
  const [rates, setRates] = useState<IRate[]>([]);
  const [addons, setAddons] = useState<IAddon[]>([]);
  const [adjPercent, setAdjPercent] = useState(0);
  const [history, setHistory] = useState<ISavedRequest[]>([]);

  // form state (numbers kept as strings so typing "1." works)
  const [name, setName] = useState('');
  const [env, setEnv] = useState<string>();
  const [workload, setWorkload] = useState<string>();
  const [os, setOs] = useState<string>();
  const [cores, setCores] = useState('4');
  const [memory, setMemory] = useState('8');
  const [storage, setStorage] = useState('150');
  const [vmCount, setVmCount] = useState('1');
  const [notes, setNotes] = useState('');
  const [addonIds, setAddonIds] = useState<number[]>([]);

  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState<string>();
  const [saveOk, setSaveOk] = useState<string>();
  const [showErrors, setShowErrors] = useState(false);

  const load = useCallback(async (): Promise<void> => {
    setLoading(true);
    setLoadError(undefined);
    try {
      const [r, a, adj, h] = await Promise.all([
        service.getRates(), service.getAddons(), service.getAdjPercent(), service.getMyRequests()
      ]);
      setRates(r); setAddons(a); setAdjPercent(adj); setHistory(h);
    } catch (e) {
      setLoadError((e as Error).message);
    } finally {
      setLoading(false);
    }
  }, [service]);

  useEffect(() => { load().catch(() => undefined); }, [load]);

  // cascading dropdowns, driven entirely by the config list
  const envs = useMemo(() => distinct(rates.map(r => r.Environment)), [rates]);
  const envSel = env && envs.indexOf(env) > -1 ? env : envs[0];
  const workloads = useMemo(
    () => distinct(rates.filter(r => r.Environment === envSel).map(r => r.Workload)), [rates, envSel]);
  const wlSel = workload && workloads.indexOf(workload) > -1 ? workload : workloads[0];
  const oss = useMemo(
    () => distinct(rates.filter(r => r.Environment === envSel && r.Workload === wlSel).map(r => r.OperatingSystem)),
    [rates, envSel, wlSel]);
  const osSel = os && oss.indexOf(os) > -1 ? os : oss[0];

  const rate: IRate | undefined = useMemo(
    () => rates.filter(r => r.Environment === envSel && r.Workload === wlSel && r.OperatingSystem === osSel)[0],
    [rates, envSel, wlSel, osSel]);

  const selectedAddons = useMemo(() => addons.filter(a => addonIds.indexOf(a.Id) > -1), [addons, addonIds]);

  const input = { cores: num(cores), memoryGB: num(memory), storageGB: num(storage), vmCount: num(vmCount) };
  const breakdown = useMemo(
    () => (rate ? calculate(rate, input, selectedAddons, adjPercent) : undefined),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [rate, cores, memory, storage, vmCount, selectedAddons, adjPercent]);

  const errors: string[] = [];
  if (!name.trim()) errors.push('Enter a request / VM name.');
  if (!rate) errors.push('No pricing found for this Environment / Workload / OS.');
  if (input.cores <= 0) errors.push('vCPU cores must be greater than 0.');
  if (input.memoryGB < 0 || input.storageGB < 0) errors.push('Memory and storage cannot be negative.');
  if (input.vmCount < 1) errors.push('Number of VMs must be at least 1.');

  const onSave = async (): Promise<void> => {
    setSaveOk(undefined); setSaveError(undefined);
    if (errors.length > 0 || !rate || !breakdown) { setShowErrors(true); return; }
    setSaving(true);
    try {
      const snapshot = {
        rate: { ...rate },
        addons: breakdown.addonLines,
        adjPercent,
        breakdown: { vcpu: breakdown.vcpu, memory: breakdown.memory, storage: breakdown.storage,
          windows: breakdown.windows, redhat: breakdown.redhat }
      };
      await service.createRequest({
        Title: name.trim(),
        Environment: envSel, Workload: wlSel, OperatingSystem: osSel,
        VcpuCores: input.cores, MemoryGB: input.memoryGB, StorageGB: input.storageGB, VmCount: input.vmCount,
        VmCost: round2(breakdown.vmCost),
        AddonsCost: round2(breakdown.addonsCost),
        AdjPercent: adjPercent,
        TotalCost: round2(breakdown.total),
        SelectedAddons: selectedAddons.map(a => a.Title).join('; '),
        RatesSnapshot: JSON.stringify(snapshot),
        Notes: notes
      });
      setSaveOk(`Saved "${name.trim()}" – total ${money(round2(breakdown.total))}.`);
      setName(''); setNotes(''); setShowErrors(false);
      setHistory(await service.getMyRequests());
    } catch (e) {
      setSaveError((e as Error).message);
    } finally {
      setSaving(false);
    }
  };

  const onReset = (): void => {
    setName(''); setNotes(''); setCores('4'); setMemory('8'); setStorage('150'); setVmCount('1');
    setAddonIds([]); setShowErrors(false); setSaveOk(undefined); setSaveError(undefined);
  };

  if (loading) return <Spinner size={SpinnerSize.large} label="Loading pricing…" />;
  if (loadError) {
    return (
      <MessageBar messageBarType={MessageBarType.error} actions={<DefaultButton onClick={() => { load().catch(() => undefined); }}>Retry</DefaultButton>}>
        {loadError}
      </MessageBar>
    );
  }
  if (rates.length === 0) {
    return <MessageBar messageBarType={MessageBarType.warning}>
      The “VM Cost Rates” list has no active rows. Add pricing in <a href={service.listUrl('rates')} target="_blank" rel="noreferrer">the rates list</a>.
    </MessageBar>;
  }

  return (
    <div className={styles.vmCostCalculator}>
      <div className={styles.header}>
        <h2 className={styles.title}>VM Cost Calculator</h2>
        <div className={styles.links}>
          <span className={styles.subtle}>Configuration:</span>
          <a href={service.listUrl('rates')} target="_blank" rel="noreferrer">Pricing rates</a>
          <a href={service.listUrl('addons')} target="_blank" rel="noreferrer">Add-ons</a>
          <a href={service.listUrl('settings')} target="_blank" rel="noreferrer">Settings</a>
          <a href={service.listUrl('requests')} target="_blank" rel="noreferrer">All estimates</a>
        </div>
      </div>

      {saveOk && <MessageBar className={styles.msg} messageBarType={MessageBarType.success} onDismiss={() => setSaveOk(undefined)}>{saveOk}</MessageBar>}
      {saveError && <MessageBar className={styles.msg} messageBarType={MessageBarType.error} onDismiss={() => setSaveError(undefined)}>{saveError}</MessageBar>}
      {showErrors && errors.length > 0 && (
        <MessageBar className={styles.msg} messageBarType={MessageBarType.warning}>{errors.join(' ')}</MessageBar>
      )}

      <div className={styles.grid}>
        <div className={styles.card}>
          <h3 className={styles.cardTitle}>VM requirements</h3>
          <TextField label="Request / VM name" required value={name} onChange={(_, v) => setName(v || '')} />
          <div className={styles.row3}>
            <Dropdown label="Environment" required options={toOptions(envs)} selectedKey={envSel}
              onChange={(_, o) => setEnv(o ? String(o.key) : undefined)} />
            <Dropdown label="Workload" required options={toOptions(workloads)} selectedKey={wlSel}
              onChange={(_, o) => setWorkload(o ? String(o.key) : undefined)} />
            <Dropdown label="Operating system" required options={toOptions(oss)} selectedKey={osSel}
              onChange={(_, o) => setOs(o ? String(o.key) : undefined)} />
          </div>
          <div className={styles.row2}>
            <TextField label="vCPU (cores)" type="number" min={1} value={cores} onChange={(_, v) => setCores(v || '')} />
            <TextField label="Number of VMs" type="number" min={1} value={vmCount} onChange={(_, v) => setVmCount(v || '')} />
            <TextField label="Memory (GB)" type="number" min={0} value={memory} onChange={(_, v) => setMemory(v || '')} />
            <TextField label="Storage (GB)" type="number" min={0} value={storage} onChange={(_, v) => setStorage(v || '')} />
          </div>
          {addons.length > 0 && (
            <>
              <div style={{ marginTop: 14, fontWeight: 600 }}>Optional add-ons</div>
              <div className={styles.addons}>
                {addons.map(a => (
                  <Checkbox key={a.Id} label={`${a.Title} – ${money(a.UnitPrice)} ${a.Basis.toLowerCase()}`}
                    checked={addonIds.indexOf(a.Id) > -1}
                    onChange={(_, c) => setAddonIds(c ? addonIds.concat([a.Id]) : addonIds.filter(i => i !== a.Id))} />
                ))}
              </div>
            </>
          )}
          <TextField label="Notes" multiline rows={2} value={notes} onChange={(_, v) => setNotes(v || '')} />
        </div>

        <div className={`${styles.card} ${styles.summary}`}>
          <h3 className={styles.cardTitle}>Cost estimate</h3>
          {breakdown && rate ? (
            <>
              <div className={styles.line}><span>vCPU<small>{input.cores} × {money(rate.VcpuCost)}</small></span><span>{money(breakdown.vcpu)}</span></div>
              <div className={styles.line}><span>Memory<small>{input.memoryGB} GB × {money(rate.MemoryCost)}</small></span><span>{money(breakdown.memory)}</span></div>
              <div className={styles.line}><span>Storage<small>{input.storageGB} GB × {money(rate.StorageCost)}</small></span><span>{money(breakdown.storage)}</span></div>
              {rate.WindowsOSCost > 0 && (
                <div className={styles.line}><span>Windows OS<small>{input.cores} vCPU × {money(rate.WindowsOSCost)}</small></span><span>{money(breakdown.windows)}</span></div>
              )}
              {rate.RedhatLicenseCost > 0 && (
                <div className={styles.line}><span>Red Hat license<small>per VM</small></span><span>{money(breakdown.redhat)}</span></div>
              )}
              <div className={styles.line}><strong>VM cost (per VM)</strong><strong>{money(breakdown.vmCost)}</strong></div>
              {breakdown.addonLines.map(l => (
                <div key={l.id} className={styles.line}><span>{l.name}<small>{l.quantity} × {money(l.unitPrice)}</small></span><span>{money(l.amount)}</span></div>
              ))}
              {input.vmCount > 1 && (
                <div className={styles.line}><span>× {input.vmCount} VMs</span><span>{money(breakdown.subtotal)}</span></div>
              )}
              <div className={styles.line}><span>Cost increase adjustment ({adjPercent}%)</span><span>{money(breakdown.adjAmount)}</span></div>
              <div className={styles.total}>
                <span className={styles.totalLabel}>Total cost</span>
                <span className={styles.totalValue}>{money(breakdown.total)}</span>
              </div>
            </>
          ) : (
            <MessageBar messageBarType={MessageBarType.warning}>No pricing row exists for this combination.</MessageBar>
          )}
          <div className={styles.actions}>
            <PrimaryButton text={saving ? 'Saving…' : 'Save estimate'} disabled={saving} onClick={() => { onSave().catch(() => undefined); }} />
            <DefaultButton text="Reset" disabled={saving} onClick={onReset} />
          </div>
        </div>
      </div>

      {history.length > 0 && (
        <div className={`${styles.card} ${styles.history}`}>
          <h3 className={styles.cardTitle}>My recent estimates</h3>
          <table>
            <thead><tr><th>Name</th><th>Environment</th><th>Workload</th><th>OS</th><th className={styles.amount}>Total</th><th>Saved</th></tr></thead>
            <tbody>
              {history.map(h => (
                <tr key={h.Id}>
                  <td>{h.Title}</td><td>{h.Environment}</td><td>{h.Workload}</td><td>{h.OperatingSystem}</td>
                  <td className={styles.amount}>{money(h.TotalCost)}</td>
                  <td>{new Date(h.Created).toLocaleDateString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default VmCostCalculator;
