import { VmCostService } from '../../../services/VmCostService';

export interface IVmCostCalculatorProps {
  service: VmCostService;
}
